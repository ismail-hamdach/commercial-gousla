

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
            <div class="page-header">
                <div class="d-flex justify-content-between text-center">
                    <h2 class="pageheader-title">Gestion des Clients des employees</h2>
                </div>
                <hr>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
            <div class="row">
                <!-- ============================================================== -->
                <!-- data table  -->
                <!-- ============================================================== -->
                <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                    <div class="card">
                        <div class="card-header d-flex justify-content-between">
                            <h5 class="mb-0">Touts les Clients</h5>
                            
                        </div>

                        <div class="card-body">
                            <form action="" class="d-flex justify-center mb-5">
                                <div class="row">
                                    <div class="col-md-4 col-sm-12 ">
                                        <label for="">Date début</label>
                                        <input type="date" class="form-control date_debut" name="date_debut">
                                    </div>
                                    <div class="col-md-4 col-sm-12">
                                        <label for="">Date fin</label>
                                        <input type="date" class="form-control date_fin" name="date_fin">
                                    </div>
                                    <div class="col-md-4 col-sm-12">
                                        <label for="">Employee</label>
                                        <select class="form-control" name="user_id">
                                            <option value="0">Tous</option>
                                            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($user->id); ?>"><?php echo e($user->name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                    <div class="col-md-4 col-sm-12 d-flex justify-center align-middle">
                                        <button type="submit"
                                            class="btn btn-info mt-3 btn_search rounded">Recherche</button>&nbsp;
                                        <a href="<?php echo e(route('employees.clients')); ?>"
                                            class="btn btn-warning mt-3 btn_cancel rounded">Annuler</a>
                                    </div>
                                </div>
                            </form>
                            <div class="table-responsive">
                                <input type="hidden" value="Utilisateurs data" id="dataa">
                                <table id="example" class="table table-striped table-bordered second" style="width:100%">
                                    <thead>
                                        <tr>
                                            <th>ID</th>
                                            <th>Nom</th>
                                            <th>Adresse</th>
                                            <th>Email</th>
                                            <th>Téléphone</th>
                                            <th>ICE</th>
                                            <?php if(boolval($user_id == 0)): ?>
                                                <th>Gérer par</th>
                                            <?php endif; ?>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($client->id); ?></td>
                                                <td><?php echo e($client->name); ?></td>
                                                <td><?php echo e($client->addresse); ?></td>
                                                <td><?php echo e($client->email); ?></td>
                                                <td><?php echo e($client->phone); ?></td>
                                                <td><?php echo e($client->ICE); ?></td>
                                                <?php if(boolval($user_id == 0)): ?>
                                                    <td><?php echo e($client->user->name); ?></td>
                                                <?php endif; ?>
                                                <td style="width:10%;">
                                                    <div class="d-flex justify-content-between">
                                                        <a href="<?php echo e(route('clients.edit', $client->id)); ?>"
                                                            class="btn btn-primary rounded">Editer</a>
                                                        <a href="#" class="btn btn-danger rounded "
                                                            data-toggle="modal" data-clientId="<?php echo e($client->id); ?>"
                                                            data-target="#deletemodal">Supprimer</a>
                                                    </div>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- ============================================================== -->
                <!-- end data table  -->
                <!-- ============================================================== -->
            </div>
        </div>

        <!-- modal delete -->
        <!-- =============================== -->
        <div class="modal fade" id="deletemodal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
            aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel">Supprimer!!</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        Voulez-vous vraiment supprimer?
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-dark rounded" data-dismiss="modal">Annuler</button>
                        <form action="" method="POST">
                            <?php echo method_field('DELETE'); ?>
                            <?php echo csrf_field(); ?>
                            <input type="hidden" id="client_ID" name="client_ID" value="">
                            <button type="submit" onclick="event.preventDefault(); this.closest('form').submit();"
                                class="btn btn-danger rounded">Supprimer</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <!-- ====================================== -->
        <!-- end modal delete -->
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js_client_page'); ?>
    <script>
        $('#deletemodal').on('show.bs.modal', function(event) {
            var button = $(event.relatedTarget) // Button that triggered the modal
            var clientID = button.attr('data-clientId') // Extract info from data-* attributes
            // If necessary, you could initiate an AJAX request here (and then do the updating in a callback).
            // Update the modal's content. We'll use jQuery here, but you could use a data binding library or other methods instead.
            var modal = $(this)
            modal.find('.modal-footer #client_ID').val(clientID)
            modal.find('form').attr('action', '/clients/' + clientID)
        });
    </script>

    <?php if(Session::has('success')): ?>
        <script>
            toastr.success("<?php echo Session::get('success'); ?>")
        </script>
    <?php endif; ?>
    <?php if(Session::has('error')): ?>
        <script>
            toastr.error("<?php echo Session::get('error'); ?>")
        </script>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Dashboard.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\E495\Documents\gousla\resources\views/Dashboard/employees/clients.blade.php ENDPATH**/ ?>