

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
            <div class="page-header">
                <div class="d-flex justify-content-between text-center">
                    <h2 class="pageheader-title">Gestion des categories pour les employees</h2>
                </div>
                <hr>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
            <div class="row">
                <!-- ============================================================== -->
                <!-- data table  -->
                <!-- ============================================================== -->
                <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                    <div class="card">

                        <div class="card-header d-flex justify-content-between">
                            <form action="" class="d-flex justify-center mb-5">
                                <div class="row">
                                    <div class="col-md-4 col-sm-12">
                                        <label for="">Employee</label>
                                        <select class="form-control" name="user_id">
                                            <option value="0">Tous</option>
                                            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($user->id); ?>"><?php echo e($user->name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                    <div class="col-md-4 col-sm-12 d-flex justify-center align-middle">
                                        <button type="submit"
                                            class="btn btn-info mt-3 btn_search rounded">Recherche</button>&nbsp;
                                        <a href="<?php echo e(route('employeescategories.index')); ?>"
                                            class="btn btn-warning mt-3 btn_cancel rounded">Annuler</a>
                                    </div>
                                </div>
                            </form>
                            <h5 class="mb-0"></h5>
                            <a href="<?php echo e(route('employeescategories.create')); ?>" class=" text-success">Ajouter un categorie <i
                                    class=" fas fa-plus-circle"></i></a>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <input type="hidden" value="Utilisateurs data" id="dataa">
                                <table id="example" class="table table-striped table-bordered second" style="width:100%">
                                    <thead>
                                        <tr>
                                            <th>ID</th>
                                            <th>Nom</th>
                                            <th>Gérer par</th>
                                            <th>Actions</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td class="text-center"><?php echo e($category->id); ?></td>
                                                <td class="text-center"><?php echo e($category->name); ?></td>
                                                <td class="text-center"><?php echo e($category->user->name); ?></td>
                                                <td style="width:10%;">
                                                    <div class="d-flex justify-content-between">
                                                        <a href="<?php echo e(route('employeescategories.edit', $category->id)); ?>"
                                                            class="btn btn-primary rounded">Editer</a>
                                                        <a href="#" class="btn btn-danger rounded "
                                                            data-toggle="modal" data-categoryId="<?php echo e($category->id); ?>"
                                                            data-target="#deletemodal">Supprimer</a>
                                                    </div>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- ============================================================== -->
                <!-- end data table  -->
                <!-- ============================================================== -->
            </div>
        </div>

        <!-- modal delete -->
        <!-- =============================== -->
        <div class="modal fade" id="deletemodal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
            aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel">Supprimer!!</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        Voulez-vous vraiment supprimer?
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-dark rounded" data-dismiss="modal">Annuler</button>
                        <form action="" method="POST">
                            <?php echo method_field('DELETE'); ?>
                            <?php echo csrf_field(); ?>
                          
                            <button type="submit" onclick="event.preventDefault(); this.closest('form').submit();"
                                class="btn btn-danger rounded">Supprimer</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <!-- ====================================== -->
        <!-- end modal delete -->
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js_product_page'); ?>
    <script>
        $('#deletemodal').on('show.bs.modal', function(event) {
            var button = $(event.relatedTarget) // Button that triggered the modal
            var categoryId = button.attr('data-categoryId') // Extract info from data-* attributes
            // If necessary, you could initiate an AJAX request here (and then do the updating in a callback).
            // Update the modal's content. We'll use jQuery here, but you could use a data binding library or other methods instead.
            var modal = $(this)
            modal.find('.modal-footer #categorie_ID').val(categoryId)
            modal.find('form').attr('action', '/employeescategories/' + categoryId)
        });
    </script>

    <?php if(Session::has('success')): ?>
        <script>
            toastr.success("<?php echo Session::get('success'); ?>")
        </script>
    <?php endif; ?>
    <?php if(Session::has('error')): ?>
        <script>
            toastr.error("<?php echo Session::get('error'); ?>")
        </script>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Dashboard.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\E495\Documents\gousla\resources\views/Dashboard/employees/categories/categories.blade.php ENDPATH**/ ?>