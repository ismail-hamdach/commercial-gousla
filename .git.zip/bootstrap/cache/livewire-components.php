<?php return array (
  'search-client' => 'App\\Http\\Livewire\\SearchClient',
  'search-product' => 'App\\Http\\Livewire\\SearchProduct',
);