

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
        <div class="page-header">
            <h2 class="pageheader-title">Gestion des
                clients</h2>
            <hr>
        </div>
    </div>
</div>
<div class="row">
    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
        <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
            <?php else: ?>
        <?php endif; ?>
        <div class="card">
            <h5 class="card-header">Ajouter un client</h5>
            <div class="card-body">
                <form action="<?php echo e(route('clients.store')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="form-row">
                        <div class="col-xl-4 col-lg-4 col-md-12 col-sm-12 col-12 mb-2">
                            <label>Nom de client <span style="color:red;">*</span></label>
                            <input type="text" class="form-control" name="name" value="<?php echo e(old("name")); ?>" placeholder="nom de client" >
                        </div>
                        <div class="col-xl-4 col-lg-4 col-md-12 col-sm-12 col-12 mb-2">
                            <label>Email <span style="color:red;">*</span></label>
                            <input type="email" class="form-control" name="email" value="<?php echo e(old("email")); ?>" placeholder="email" >
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="col-xl-4 col-lg-4 col-md-12 col-sm-12 col-12 mb-2">
                            <label for="validationCustom03">Adresse <span style="color:red;">*</span></label>
                            <input type="text" class="form-control" name="addresse" value="<?php echo e(old("addresse")); ?>" placeholder="adresse" >
                        </div>
                        <div class="col-xl-4 col-lg-4 col-md-12 col-sm-12 col-12 mb-2">
                            <label>Téléphone <span style="color:red;">*</span></label>
                            <input type="text" class="form-control" name="phone" value="<?php echo e(old("phone")); ?>" placeholder="Téléphone" >
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="col-xl-4 col-lg-4 col-md-12 col-sm-12 col-12 mb-2">
                            <label for="validationCustom03">ICE :</label>
                            <input type="text" class="form-control" name="ICE" value="<?php echo e(old("ICE")); ?>" placeholder="ICE" >
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 ">
                            <button class="btn btn-primary" type="submit">Valider</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Dashboard.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home4/zuegelze/gousla.gousla.com/resources/views/Dashboard/admin/clients/create.blade.php ENDPATH**/ ?>