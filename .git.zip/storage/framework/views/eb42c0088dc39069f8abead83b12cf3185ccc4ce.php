

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
        <div class="page-header">
            <h2 class="pageheader-title">Paramètres de l'entreprise </h2>
            <hr>
        </div>
    </div>
</div>
<div class="row">
    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
        <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
            <?php else: ?>
        <?php endif; ?>
        <div class="card">
            <h5 class="card-header">Inserer les paramètres de votre entreprise</h5>
            <div class="card-body ">
                <form class="needs-validation" action="<?php echo e(route('companys.store')); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="row">
                        <div class="col-xl-8 col-lg-8 col-md-12 col-sm-12">
                            <div class="row">
                                <div class="col-md-6">
                                    <label for="validationCustom03" class="mt-3">Nom de société :</label>
                                    <input type="text" class="form-control" name="name"  id="validationCustom03" placeholder="Nom de société" required>
                                </div>
                                <div class="col-md-6">
                                    <label for="validationCustom04" class="mt-3">Adresse :</label>
                                    <input type="text" class="form-control" name="addresse" id="validationCustom04" placeholder="Adresse" required>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6">
                                    <label for="validationCustom03" class="mt-3">Téléphone :</label>
                                    <input type="text" name="phone" class="form-control" id="validationCustom03" placeholder="telephone">
                                </div>
                                <div class="col-md-6">
                                    <label for="validationCustom03" class="mt-3">GSM :</label>
                                    <input type="text" name="GSM" class="form-control" id="validationCustom03" placeholder="GSM" >
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6">
                                    <label for="validationCustom04" class="mt-3">ICE :</label>
                                    <input type="text" class="form-control" name="ICE" id="validationCustom04"  placeholder="ICE" required>
                                </div>
                                <div class="col-md-6">
                                    <label for="validationCustom03" class="mt-3">Email :</label>
                                    <input type="email" name="email" class="form-control" id="validationCustom03"  placeholder="Email" required>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6">
                                    <label for="validationCustom04" class="mt-3">Numéro de registre de commerce :</label>
                                    <input type="number" class="form-control" name="RC" id="validationCustom04"  placeholder="RC" required>
                                </div>
                                <div class="col-md-6">
                                    <label for="validationCustom03" class="mt-3">Identifiant taxe professionnelle :</label>
                                    <input type="number" name="TP" class="form-control" id="validationCustom03"  placeholder="TP" required>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6">
                                    <label for="validationCustom04" class="mt-3">Identification fiscal :</label>
                                    <input type="number" class="form-control" name="IF" id="validationCustom04"  placeholder="IF" required>
                                </div>
                            </div>
                        </div>
                        <div class="col-xl-4 col-lg-4 col-md-12 col-sm-12 mt-3">
                            <div class="imgUp">
                                <div class="imagePreview"></div>
                                <label class="btn btn-info w-100">
                                    Uploader<input type="file" name="logo" class="uploadFile img" value="Upload Photo" style="width: 0px;height: 0px;overflow: hidden;">
                                </label>
                            </div>
                        </div>
                    </div>
                    <div class="row mt-3">
                        <button class="btn btn-primary" type="submit">Valider</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Dashboard.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/zuegelze/gousla.gousla.com/resources/views/Dashboard/admin/company/create.blade.php ENDPATH**/ ?>