<img src="<?php echo e(asset('assets/images/gousla.jpeg')); ?>" width="250px" alt="">
<?php /**PATH C:\Users\E495\Documents\gousla\resources\views/components/application-logo.blade.php ENDPATH**/ ?>