<img src="{{ asset('assets/images/app.png') }}" width="250px" alt="">
